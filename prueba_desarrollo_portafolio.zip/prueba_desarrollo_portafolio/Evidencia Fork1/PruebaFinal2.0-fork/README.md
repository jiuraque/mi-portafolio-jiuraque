# PruebaFinal2.0
Segunda version de la prueba final del modulo 1
# acceso de mi github para revision de mi prueba
https://github.com/Row-Diaz/PruebaFinal2.0.git

# link del deploy de mi proyecto:
https://row-diaz.github.io/PruebaFinal2.0/ 

# acceso del repositorio forkeado del compañero N° 1
https://github.com/Row-Diaz/dl-m01-compa-ero1.git

# acceso del repositorio forkeado del compañero N° 2
https://github.com/Row-Diaz/compa-ero2.git